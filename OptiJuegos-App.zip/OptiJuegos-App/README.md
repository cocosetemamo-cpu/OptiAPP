# OptiJuegos App

App Android (WebView, no PWA) que carga https://optijuegos.net a pantalla completa, sin barra de URL,
sin menu contextual ni seleccion de texto, con descargas dentro de la app.

## Compilar el APK con GitHub Actions

1. Crea un repositorio nuevo en GitHub (vacio).
2. En la carpeta del proyecto (descomprimida), abre una terminal y ejecuta:
   ```
   git init
   git add .
   git commit -m "OptiJuegos app"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/TU_REPO.git
   git push -u origin main
   ```
   (Importante: debe subirse la carpeta oculta `.github`.)
3. En GitHub entra a la pestaña **Actions**. Se ejecuta solo "Build APK" (tarda unos 3-5 min).
   Si no, pulsa **Run workflow**.
4. Al terminar, abre la ejecucion y baja **OptiJuegos-APK** desde *Artifacts* (viene en un .zip con `OptiJuegos.apk`).

### Enlace publico para la web de descarga
Crea un tag y se publica en Releases:
```
git tag v1.0
git push origin v1.0
```
El APK queda en `https://github.com/TU_USUARIO/TU_REPO/releases/latest/download/OptiJuegos.apk`.
Pega ese enlace en `landing/index.html` (donde dice `TU_LINK_DEL_APK_AQUI`).

## Personalizar
- Nombre: `app/src/main/res/values/strings.xml`
- Colores: `app/src/main/res/values/colors.xml`
- Icono: en Android Studio, click derecho en `res` > New > Image Asset (el logo esta en https://optijuegos.net/logo.png)
- URL: `HOME_URL` en `MainActivity.kt`
- Paquete: `applicationId` en `app/build.gradle.kts`
